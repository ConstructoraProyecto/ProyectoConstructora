<?php 
	session_start();
	if ($_SESSION['ROL'] == 'Usuario') {
		
	}
	else
	{
		header("Location: ../Index.php");
	}

 ?>