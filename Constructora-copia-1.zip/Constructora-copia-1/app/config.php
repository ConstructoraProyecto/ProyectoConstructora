<?php 

	return array('host'     => 'localhost',
				 'user'     => 'root',
				 'password' => '',
				 'database' => 'proyecto'
				);

 ?>