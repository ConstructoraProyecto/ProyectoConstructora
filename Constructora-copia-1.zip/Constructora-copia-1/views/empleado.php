<?php 

  require_once '../app/validacionGeneral.php';

 ?>

<!DOCTYPE html>
<html lang="en">

<head>
<?php require '../app/head.php'; ?>
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
    <?php require '../app/menu.php'; ?>
    <div class="content-wrapper">

    <div class="container-fluid">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"> Gestión de Recurso Humano </li>
        <li class="breadcrumb-item active"><b> Administrador </b></li>
      </ol>
    </div>
    <div class="col-lg-12">
      <div class="card mb-3">
        <div class="card-header">
           <b>Modulo Recurso Humano</b>
        </div>
        <div class="card-body"> 
          <div class="row">
            
            <div class="col-sm-6 my-auto">
              <label class="çontrol-label"><b>Nombre</b></label>
              <input type="text" name="nombres" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <label class="control-label"><b>Codigo</b></label>
              <input type="text" name="codigo" class="form-control">
            </div>           
            <div class="col-sm-3 text-center my-auto"></div>
            <div class="col-sm-6 my-auto">
              <br>
              <label class="çontrol-label"><b>Correo Electronico</b></label>
              <input type="text" name="correo" placeholder="ejemplo@correo.com" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="çontrol-label"><b>Telefono</b></label>
              <input type="text" name="telefono" class="form-control">
            </div>
            <div class="col-sm-3 text-center my-auto"></div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="çontrol-label"><b>DUI</b></label>
              <input type="text" name="nit" placeholder="00000000-0" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="çontrol-label"><b>NIT</b></label>
              <input type="text" name="dui" placeholder="0000-0000000-000-0" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="çontrol-label"><b>ISSS</b></label>
              <input type="text" name="isss" class="form-control" placeholder="000000000">
            </div>
            <div class="col-sm-3 text-center my-auto"></div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="çontrol-label"><b>Genero:</b></label>
            </div>
            <div class="col-sm-9 my-auto"></div>
            <div class="col-sm-3 my-auto">
              <label><b>Femenino:</b></label>  &nbsp; &nbsp;<input type="radio" name="genero" value="F" >
            </div>
            <div class="col-sm-3 my-auto">
              <label><b>Masculino:</b></label>  &nbsp; &nbsp;<input type="radio" name="genero" value="M" >
            </div>
            <div class="col-sm-6 my-auto"></div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="control-label"><b>Proyecto Asignado</b></label>
              <input type="text" name="proyectoAsignado" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="control-label"><b>Sueldo Asignado</b></label>
              <input type="text" name="sueldo" class="form-control">
            </div>
            <div class="col-sm-6 my-auto"></div>
            <div class="col-sm-6 my-auto">
              <br>
              <label class="control-label"><b>Dirección</b></label>
              <textarea name="direccion" class="form-control"></textarea>
            </div>
            <div class="col-sm-6 my-auto"></div>
            
            <div class="col-sm-2 my-auto">
              <br>
              <input type="submit"  name="agregar" value="Agregar" class="btn btn-primary btn-block">
            </div>
            <div class="col-sm-2 my-auto">
              <br>
              <input type="submit"  name="modificar" value="Modificar" class="btn btn-primary btn-block">
            </div>
            <div class="col-sm-2 my-auto">
              <br>
              <input type="submit"  name="buscar" value="Buscar" class="btn btn-primary btn-block">
            </div>
            <div class="col-sm-2 my-auto">
              <br>
              <input type="submit"  name="eliminar" value="Eliminar" class="btn btn-primary btn-block">
            </div>

          </div>
        </div>

        <div class="card-footer small text-muted"></div>
      </div>
    </div>
    
  </div>
<?php require '../app/modalLogout.php'; ?>
<?php require '../app/footer.php'; ?>
    </body>

</html>

