<?php 

  require_once '../app/validacionGeneral.php';

 ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?php require '../app/head.php'; ?>
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php require '../app/menu.php'; ?>
  <div class="content-wrapper">

    <div class="container-fluid">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"> Gestión de Maquinaria </li>
        <li class="breadcrumb-item active"><b> Administrador </b></li>
      </ol>
    </div>

    <div class="col-lg-12">
      <div class="card mb-3">
        <div class="card-header">
           <b>Modulo Maquinaria</b>
        </div>
        
        <div class="card-body"> 
          <div class="row">
            
            <div class="col-sm-6 my-auto">
              <label class="control-label"><b>Nombre Maquinaria</b></label>
              <input type="text" name="nombre" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <label class="control-label"><b>Estado Maquinaria</b></label>
              <select class="form-control" id="estado" name="estado">
                <option value="disponible">Disponible</option>
                <option value="no disponible">No Disponible</option>
              </select class="selectpicker">
            </div>
            <div class="col-sm-3 my-auto"></div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="control-label"><b>Marca</b></label>
              <input type="text" name="marca" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="control-label"><b>Modelo</b></label>
              <input type="text" name="modelo" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="control-label"><b>Placa</b></label>
              <input type="text" name="placa" class="form-control">
            </div>
            <div class="col-sm-3 my-auto"></div>
            <div class="col-sm-6 my-auto">
              <br>
              <label class="control-label"><b>Descripción</b></label>        
              <textarea class= "form-control" name="descripcion"></textarea>
            </div>
            <div class="col-sm-3 my-auto">
              <label class="control-label"><b>Precio</b></label>
              <input type="text" name="precio" class="form-control">
            </div>
            <div class="col-sm-3 my-auto"></div>

            <div class="col-sm-2 my-auto">
              <br>
              <input type="submit"  name="agregar" value="Agregar" class="btn btn-primary btn-block">
            </div>
            <div class="col-sm-2 my-auto">
              <br>
              <input type="submit"  name="modificar" value="Modificar" class="btn btn-primary btn-block">
            </div>
            <div class="col-sm-2 my-auto">
              <br>
              <input type="submit"  name="buscar" value="Buscar" class="btn btn-primary btn-block">
            </div>
            <div class="col-sm-2 my-auto">
              <br>
              <input type="submit"  name="eliminar" value="Eliminar" class="btn btn-primary btn-block">
            </div>

          </div>
        </div>

        <div class="card-footer small text-muted"></div>
      </div>
    </div>
    
  </div>
<?php require '../app/modalLogout.php'; ?>
<?php require'../app/footer.php'; ?>
    
</body>

</html>
