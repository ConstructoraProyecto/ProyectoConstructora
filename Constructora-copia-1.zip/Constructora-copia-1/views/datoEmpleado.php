<?php require_once '../app/ValidacionUsuario.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <?php require '../app/head.php'; ?>
</head>
<body class="fixed-nav sticky-footer bg-dark">
  
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="empleadoDatos.php"><b>INICIO</b></a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="datoEmpleado.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">EMPLEADO</span>
          </a>
        </li>
      </ul>
    </div>

    <div class="collapse navbar-collapse" id="navbarResponsive">
       <ul class="navbar-nav sidenav-toggler">
      <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>   
      </ul>

      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>
      </ul>
    </div>
  </nav>
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Your Website 2018</small>
        </div>
      </div>
    </footer>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>


  <div class="content-wrapper">
        <div class="container-fluid">
        <ol class="breadcrumb">
        <li class="breadcrumb-item"> Bienvenido </li>
        <li class="breadcrumb-item active"><b>Usuario </b></li>
        </ol>
    </div>
      <div class="container-fluid">
       <div class="row">
         <div class="col-sm-4 my-auto">    
        </div> 
        <div class="col-sm-3 my-auto">
              <label class="control-label"><b>Codigo</b></label>
              <input type="text" name="codigo" class="form-control">
        </div> 
        <div class="col-sm-5 my-auto"></div>
        <div class="col-sm-4 my-auto">    
        </div> 
        <div class="col-sm-3 my-auto"><br>
              <input type="submit"  name="buscar" value="Buscar" class="btn btn-primary btn-block">
        </div> 

       </div>
    </div>
  </div>


   <?php require "../app/modalLogout.php" ;?>
   <?php require "../app/footer.php"; ?>
</body>
</html>