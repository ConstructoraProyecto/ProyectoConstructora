<?php  
  require_once '../app/validacionGeneral.php';
  //require_once '../controller/dashboardController.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php require "../app/head.php"; ?>
</head>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
      <?php require "../app/menu.php"; ?>
       <div class="content-wrapper">
        <div class="container-fluid">
        <ol class="breadcrumb">
        <li class="breadcrumb-item"> Bienvenido </li>
        <li class="breadcrumb-item active"><b> Administrador </b></li>
        </ol>
    </div>

    <div class="container-fluid">
      <img src="../img/dashboard/2.jpg" width="1080" height="500">
    </div>
  </div>
    <?php require "../app/modalLogout.php"; ?>
    <?php require "../app/footer.php" ;?>
</body>
</html>