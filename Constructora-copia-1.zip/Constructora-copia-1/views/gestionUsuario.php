<?php 
	require_once '../app/validacionGeneral.php';
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php require '../app/head.php'; ?>
</head>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php require '../app/menu.php'; ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"> Gestión de Usuarios </li>
        <li class="breadcrumb-item active"><b> Administrador </b></li>
      </ol>
    </div>
    <div class="col-lg-12">
      <div class="card mb-3">
        <div class="card-header">
           <b>Modulo Gestión de Usuarios</b>
        </div>
        
        <div class="card-body"> 
          <div class="row">

          </div>
        </div>

        <div class="card-footer small text-muted"></div>
      </div>
    </div>
    
  </div>
<?php require '../app/modalLogout.php'; ?>
<?php require'../app/footer.php' ;?>
    
</body>

</html>