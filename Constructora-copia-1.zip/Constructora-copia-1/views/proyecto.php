<?php 
  require_once '../app/validacionGeneral.php';
  require_once '../controller/proyectoController.php'; 
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <?php require '../app/head.php'; ?>
</head>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php require'../app/menu.php'; ?>
  <div class="content-wrapper">

    <div class="container-fluid">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"> Gestión de Proyectos </li>
        <li class="breadcrumb-item active"><b> Administrador </b></li>
      </ol>
    </div>

    <div class="col-lg-12">
      <div class="card mb-3">
        <div class="card-header">
           <b>Modulo Proyectos</b>
        </div>
        
        <div class="card-body"> 
          <div class="row" id="infoUsuario">

            <div class="col-sm-3 my-auto">
              <label class="control-label"><b>Nombre Proyecto</b></label>
              <input type="text" name="nombre" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <label class="control-label"><b>Codigo</b></label>
              <input type="text" name="codigo" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <label class="control-label"><b>Estado del Proyecto</b></label>
              <select class="form-control" id="estado" name="estado">
                <option value="ejecucion">En Ejecución</option>
                <option value="terminado">Terminado</option>
              </select class="selectpicker">
            </div>
            <div class="col-sm-3 my-auto"></div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="control-label"><b>Encargado del Proyecto</b></label>
              <input type="text" name="encargado" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="control-label"><b>Fecha Inicio</b></label>
              <input type="date" name="fechaInicio" class="form-control">
            </div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="control-label"><b>Fecha Finalización</b></label>
              <input type="date" name="fechaFin" class="form-control">
            </div>
            <div class="col-sm-3 my-auto"></div>
            <div class="col-sm-3 my-auto">
              <br>
              <label class="control-label"><b>Gastos Totales</b></label>
              <input type="text" name="gastosTotales" class="form-control">
            </div>

          </div>
        </div>

        <div class="card-footer small text-muted"></div>
      </div>
    </div>

    <div class="col-lg-12">
      <div class="card mb-3">
        <div class="card-header">
           <b>Ubicacion Proyecto</b>
        </div>
        
        <div class="card-body"> 
          <div class="row" id="infoUsuario">

            <div class="col-sm-6 my-auto">
              <label class="control-label"><b>Ubicación</b></label>
              <input type="text" name="ubicacion" id="us3-address" class="form-control">
              <br>
            </div>
            <div class="col-sm-3 my-auto">
              <label class="control-label"><b>Latitud</b></label>
              <input type="text" name="latitud" id="us3-lat" class="form-control">
              <br>
            </div>
            <div class="col-sm-3 my-auto">
              <label class="control-label"><b>Longitud</b></label>
              <input type="text" name="longitud" id="us3-lon" class="form-control">
              <br>
            </div>
            <div id="us3" style="width: 1100px; height: 500px;"></div>

            <script>
                  $('#us3').locationpicker({
                      location: {
                          latitude: 13.6740443,
                          longitude: -89.2794867
                      },
                      radius: 100,
                      inputBinding: {
                          latitudeInput: $('#us3-lat'),
                          longitudeInput: $('#us3-lon'),
                          radiusInput: $('#us3-radius'),
                          locationNameInput: $('#us3-address')
                      },
                      enableAutocomplete: true,
                      onchanged: function (currentLocation, radius, isMarkerDropped) {
                          // Uncomment line below to show alert on each Location Changed event
                          //alert("Location changed. New location (" + currentLocation.latitude + ", " + currentLocation.longitude + ")");
                      }
                  });
              </script>

          </div>
        </div>

        <div class="card-footer small text-muted"></div>
      </div>
    </div>

    <div class="col-lg-12">
      <div class="card mb-3">
        
        <div class="card-body"> 
          <div class="row">

            <div class="col-sm-2 my-auto">
              <input type="submit"  name="agregar" value="Agregar" id="agregarProyecto" class="btn btn-primary btn-block">
            </div>
            <div class="col-sm-2 my-auto">
              <a href="viewProyecto.php">
                <input type="submit"  name="mostrar" value="Mostrar" class="btn btn-primary btn-block">
              </a>
            </div>
            <!--<div class="col-sm-2 my-auto">
              <input type="submit"  name="buscar" value="Buscar" class="btn btn-primary btn-block">
            </div>
            <div class="col-sm-2 my-auto">
              <input type="submit"  name="eliminar" value="Eliminar" class="btn btn-primary btn-block">
            </div>-->           
           
          </div>
        </div>

        <div class="card-footer small text-muted"></div>
      </div>

    </div>

  </div>
<?php require '../app/modalLogout.php'; ?>
<?php require '../app/footer.php'; ?>
   
</body>

</html>