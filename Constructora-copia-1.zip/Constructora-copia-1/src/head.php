
<!-- CSS -->
<link rel="stylesheet" type="text/css" href="../plugins/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../plugins/dataTable/material.min.css">
<link rel="stylesheet" type="text/css" href="../plugins/dataTable/dataTables.material.min.css">
<link rel="stylesheet" type="text/css" href="../plugins/sweetalert-master/dist/sweetalert.css">

<!-- JS -->
<script type="text/javascript" src="../plugins/jquery/jquery-3.3.1.js"></script>
<script type="text/javascript" src="../plugins/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../plugins/dataTable/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../plugins/dataTable/dataTables.material.min.js"></script>
<script type="text/javascript" src="../plugins/jQuery-Mask/src/jquery.mask.js"></script>
<script type="text/javascript" src="../plugins/sweetalert-master/dist/sweetalert.min.js"></script>	


