<?php 
	require_once 'Conexion.php';
	/**
	* 
	*/
	class Usuario extends Conexion
	{
		private $username;
		private $password;
		private $estado;
		private $rol;
		
		function __construct()
		{
			parent::__construct();
		}

		public function setUserName($username)
		{
			$this->username = $username;
		}

		public function getUserName()
		{
			return $this->username;
		}


		public function setPassword($password)
		{
			$this->password = $password;
		}

		public function getPassword()
		{
			return $this->password;
		}


		public function setEstado($estado)
		{
			$this->estado = $estado;
		}

		public function getEstado()
		{
			return $this->estado;
		}


		public function setRol($rol)
		{
			$this->rol = $rol;
		}

		public function getRol()
		{
			return $this->rol;
		}


		public function EncripPassword($password)
		{
			$passwordEncrip = sha1($password);
			return $passwordEncrip;
		}

		public function login($username, $password)
		{
			$con = $this->conectar();
         //$passReal = $this->EncripPassword($password) ;

			$sql = "SELECT u.nombre_Usuario as usuario, r.tipo_Rol as rol 
					FROM usuario u INNER JOIN rol r 
					ON u.id_Rol = r.id_Rol 
					WHERE u.estado = 1 AND r.estado = 1 
					AND u.nombre_Usuario = '".$username."' AND u.pass ='".$password."'";

			$info = $con->query($sql);
			//print_r($info);
			//die();

			if ($info->num_rows > 0) 
			{   
				$data = $info->fetch_assoc();
				session_start();
				$_SESSION['ROL'] = $data['rol'];
				
			    if($_SESSION['ROL']=='Administrador')
				{
					header('Location:../views/dashboard.php');
				}

				if ($_SESSION['ROL']=='Usuario') {
				     header("Location: ../views/empleadoDatos.php");
				}
			}
			else
			{
				header("Location: ../Index.php");
			}
		}

	}

 ?>