<?php 
    
    require_once 'Conexion.php';

	class Proyecto extends Conexion
	{

		private $nombre;
		private $fechaInicio;
        private $fechaFin;
		private $encargado;
		private $gastoTotal;
        private $estado;
        private $codigo;
        private $latitud;
        private $longitud;
        private $estado_proyecto;
        
		public function __construct()
		{    
            parent::__construct();
        }


    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     *
     * @return self
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getFechaInicio()
    {
        return $this->fechaInicio;
    }

    /**
     * @param mixed $fechaInicio
     *
     * @return self
     */
    public function setFechaInicio($fechaInicio)
    {
        $this->fechaInicio = $fechaInicio;

        return $this->fechaInicio;
    }

    /**
     * @return mixed
     */
    public function getFechaFin()
    {
        return $this->fechaFin;
    }

    /**
     * @param mixed $fechaFin
     *
     * @return self
     */
    public function setFechaFin($fechaFin)
    {
        $this->fechaFin = $fechaFin;

        return $this->fechaFin;
    }

    /**
     * @return mixed
     */
    public function getEncargado()
    {
        return $this->encargado;
    }

    /**
     * @param mixed $encargado
     *
     * @return self
     */
    public function setEncargado($encargado)
    {
        $this->encargado = $encargado;

        return $this->encargado;
    }

    /**
     * @return mixed
     */
    public function getGastoTotal()
    {
        return $this->gastoTotal;
    }

    /**
     * @param mixed $gastoTotal
     *
     * @return self
     */
    public function setGastoTotal($gastoTotal)
    {
        $this->gastoTotal = $gastoTotal;

        return $this->gastoTotal;
    }

    /**
     * @return mixed
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * @param mixed $estado
     *
     * @return self
     */
    public function setEstado($estado)
    {
        $this->estado = $estado;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCodigo()
    {
        return $this->codigo;
    }

    /**
     * @param mixed $codigo
     *
     * @return self
     */
    public function setCodigo($codigo)
    {
        $this->codigo = $codigo;

        return $this->codigo;
    }

    /**
     * @return mixed
     */
    public function getEstadoProyecto()
    {
        return $this->estado_proyecto;
    }

    /**
     * @param mixed $estado_proyecto
     *
     * @return self
     */
    public function setEstadoProyecto($estado_proyecto)
    {
        $this->estado_proyecto = $estado_proyecto;

        return $this->estado_proyecto;
    }



    public function getAll()
    {
        $con = $this->conectar();
        $sqlAll = "SELECT * from proyecto WHERE estado_proyecto = 1";
        $info = $con->query($sqlAll);
        if ($info->num_rows>0) {
            
            $dato = $info;
        }else{

            $dato = false;
        }
        return $dato;
    }

    public function getAllRol()
    {
        $con = $this->conectar();
        $sql = "SELECT r.id, r.nombre FROM rol r WHERE r.estado = 1";
        $data = $con->query($sql);
        if ($data->num_rows > 0) 
        {
            $info = $data;
        }
        else
        {
            $info = null;
        }

        return $info;
    }

    public function saveUser()
    {
        $con = $this->conectar();
        $sql = "INSERT INTO proyecto values(0, '".$this->nombre."', '".$this->fechaInicio."', '".$this->fechaFin."', '".$this->encargado."', ".$this->gastoTotal.", '".$this->estado."', ".$this->codigo.", ".$this->longitud.", ".$this->latitud.", ".$this->estado_proyecto.")";
        $res = $con->query($sql);
        $data = array();
        if ($res) 
        {
            $data['estado_proyecto'] = true;
            $data['descripcion'] = 'Datos ingresados exitosamente';
        }
        else
        {
            $data['estado_proyecto'] = false;
            $data['descripcion'] = 'Ocurrio un error en la insercion';   
        }

        return json_encode($data);
    }

    /*public function updateUser()
    {
        $sql = "INSERT INTO usuario values(0, '".$this->username."', '".$this->password."', '".$this->salt."', ".$this->estado.", ".$this->rol.")";
        $res = $this->db->query($sql);
        $data = array();
        if ($res) 
        {
            $data['estado'] = true;
            $data['descripcion'] = 'Datos ingresados exitosamente';
        }
        else
        {
            $data['estado'] = false;
            $data['descripcion'] = 'Ocurrio un error en la insercion'.$this->db->error;   
        }

        return json_encode($data);
    }*/

    public function findUser($nombreUsuario)
    {
        $sql = "SELECT count(id) as numero FROM usuario WHERE username = '".$nombreUsuario."' AND estado = 1";
        $res = $this->db->query($sql);
        $data = $res->fetch_assoc();
        $arreglo = array();
        if ($data['numero'] > 0) 
        {
            $arreglo['estado'] = true;
            $arreglo['descripcion'] = "Usuario NO disponible";
        }
        else
        {
            $arreglo['estado'] = false;
            $arreglo['descripcion'] = "Usuario disponible";
        }

        return json_encode($arreglo);
    }

    public function getUser($idUsuario)
    {
        $sql = "SELECT u.id, u.username, r.id as idRol FROM usuario u 
                INNER JOIN rol r ON u.rol_id = r.id WHERE  u.id = ".$idUsuario;
        $arreglo = array();
        $info = $this->db->query($sql);
        $data = $info->fetch_assoc();

        $arreglo['idUsuario'] = $data['id'];
        $arreglo['idRol'] = $data['idRol'];
        $arreglo['username'] = $data['username'];
        $arreglo['estado'] = true;

        return json_encode($arreglo);
    }


//Fin de la clase
}


 ?>