<?php 
	require_once '../model/Proyecto.php';

	if (isset($_POST['key'])) {
		$key = $_POST['key'];
		//var_dump($key);//

		switch ($key) {
			case 'agregar':
				agregar();
			break;

			case 'findUser':
				findUser();
			break;
			
			case 'getUser':
				getUser();
			break;

			case 'editar':
				editar();
			break;

			default:
				# code...
				break;

			//Fin del switch	
		}
		//Fin del isset
	}
	
	function agregar()
	{
		$info = $_POST['dataUsuario'];
		$decodeInfo = json_decode($info);
		var_dump($decodeInfo);
		$objProyecto = new Proyecto();
		$objProyecto->setNombre($decodeInfo[0]->value);
		$objProyecto->setCodigo($decodeInfo[1]->value);
		$objProyecto->setEstado($decodeInfo[2]->value);
		$objProyecto->setEncargado($decodeInfo[3]->value);
		$objProyecto->setFechaInicio($decodeInfo[4]->value);
		$objProyecto->setFechaFin($decodeInfo[5]->value);
		$objProyecto->setGastoTotal($decodeInfo[6]->value);
		$objProyecto->setEstadoProyecto(1);
		$res =  $objProyecto->saveUser();
		echo $res;
	}

	function findUser()
	{
		$nombreUsuario = $_POST['valor'];
		$objUsuario = new Usuario();
		$res = $objUsuario->findUser($nombreUsuario);
		echo $res;
	}

	function getUser()
	{
		$idUsuario = $_POST['idUsuario'];
		$objUsuario = new Usuario();
		$res = $objUsuario->getUser($idUsuario);
		echo $res;
		//var_dump($res);
	}

 ?>