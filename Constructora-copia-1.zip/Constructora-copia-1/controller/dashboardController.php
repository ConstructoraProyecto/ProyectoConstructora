<?php 
	
	require_once '../model/Usuario.php';

	if (isset($_POST['enviarDatos'])) {

		login();
	}

	function login()
	{
		$username = $_POST['user'];
		$password = $_POST['pass'];

		$objUsuario = new Usuario();
		$objUsuario->login($username, $password);
	}

	 /*$pass = sha1("Admin");
	echo $pass;*/
 ?>

